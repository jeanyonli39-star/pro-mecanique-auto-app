
PRO_MECANIQUE_AUTO - package final
=================================

Contenu :
- web/ : version web complète (index.html = écran d'accueil, app.html = tableau de bord)
- manifest.json + icons pour PWA

Instructions rapides pour mettre en ligne (sur GitHub Pages) depuis ton téléphone :
1) Crée un dépôt sur GitHub : https://github.com/new
   - Nom du dépôt : pro-mecanique-auto
   - Visibilité : Public
2) Sur ton téléphone, ouvre github.com (ou l'app GitHub), va dans ton dépôt.
3) "Add file" -> "Upload files" -> uploade tous les fichiers du dossier web (index.html, app.html, styles.css, manifest.json, logo.png, illustration.png, icons/, icon-*.png).
4) Paramètres -> Pages -> Source: main -> root -> Save. Le site publiera en quelques minutes.
   Le lien sera : https://jeanyonli39-etoiles.github.io/pro-mecanique-auto/

Si tu veux, je peux te fournir un texte prêt à copier pour le titre et la description du dépôt GitHub.
